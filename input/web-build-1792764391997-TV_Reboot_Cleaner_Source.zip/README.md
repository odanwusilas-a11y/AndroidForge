# TV Reboot Cleaner (source project)

This is an Android TV app project, not a prebuilt APK. The current ChatGPT execution environment has no Android SDK/Gradle build toolchain and cannot reach Google's download servers, so I could not compile or verify an APK here.

## What it does
- Requests Shizuku shell permission.
- Runs `pm trim-caches 10G`.
- Waits two seconds and runs `reboot`.
- Does not clear app data or uninstall packages.

## Build an APK on Windows
1. Install Android Studio from the official Android developer website.
2. Open this folder as a project and let Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The APK should be under `app/build/outputs/apk/debug/app-debug.apk`.

## TV setup
1. Install and start Shizuku on the TV if your TCL firmware supports it.
2. Enable Developer options and Wireless debugging.
3. Pair/start Shizuku using its on-screen instructions.
4. Install the built APK and grant its Shizuku permission when prompted.

## Important
- Shizuku setup and shell command support vary by Android TV version.
- `pm trim-caches 10G` only trims caches Android considers reclaimable; it does not guarantee 10 GB free.
- The reboot command can interrupt anything currently running.
- This project has not been compiled or tested on a TCL TV in this environment.
