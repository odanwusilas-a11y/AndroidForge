package com.example.tvrebootcleaner;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.DialogInterface;
import android.app.AlertDialog;

import rikka.shizuku.Shizuku;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class MainActivity extends Activity {
    private TextView status;
    private Button cleanButton;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Shizuku.OnRequestPermissionResultListener permissionListener =
        (requestCode, grantResult) -> {
            if (requestCode == 1001) {
                if (grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    runCleanupAndReboot();
                } else {
                    setStatus("Shizuku permission was denied. Start Shizuku and grant permission to this app.");
                    setEnabled(true);
                }
            }
        };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Shizuku.addRequestPermissionResultListener(permissionListener);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(48, 32, 48, 32);
        root.setBackgroundColor(Color.rgb(16, 24, 32));

        TextView title = new TextView(this);
        title.setText("TV REBOOT CLEANER");
        title.setTextColor(Color.WHITE);
        title.setTextSize(30);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView desc = new TextView(this);
        desc.setText("Trims reclaimable app caches, then restarts Android TV. Does not erase app data.");
        desc.setTextColor(Color.rgb(195, 213, 224));
        desc.setTextSize(18);
        desc.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2);
        dp.setMargins(0, 20, 0, 28);
        root.addView(desc, dp);

        cleanButton = new Button(this);
        cleanButton.setText("CLEAN & REBOOT");
        cleanButton.setTextSize(20);
        cleanButton.setFocusable(true);
        cleanButton.setOnClickListener(v -> confirmAction());
        root.addView(cleanButton, new LinearLayout.LayoutParams(360, 72));

        status = new TextView(this);
        status.setText("Requires Shizuku running with ADB-shell access.");
        status.setTextColor(Color.rgb(120, 215, 255));
        status.setTextSize(16);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.setMargins(0, 24, 0, 0);
        root.addView(status, sp);

        setContentView(root);
        cleanButton.requestFocus();
    }

    private void confirmAction() {
        new AlertDialog.Builder(this)
            .setTitle("Clean and reboot?")
            .setMessage("The TV will restart. Unsaved activity in open apps may be interrupted. Continue?")
            .setNegativeButton("Cancel", (d, w) -> {})
            .setPositiveButton("Continue", (d, w) -> requestShellAccess())
            .show();
    }

    private void requestShellAccess() {
        if (!Shizuku.pingBinder()) {
            setStatus("Shizuku is not running. Start Shizuku using Wireless debugging, then try again.");
            return;
        }
        if (Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            runCleanupAndReboot();
        } else {
            Shizuku.requestPermission(1001);
        }
    }

    private void runCleanupAndReboot() {
        setEnabled(false);
        setStatus("Trimming reclaimable caches… TV will reboot shortly.");
        new Thread(() -> {
            try {
                Process p = Shizuku.newProcess(
                    new String[]{"sh", "-c", "pm trim-caches 10G; sleep 2; reboot"},
                    null, null);
                BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
                while (reader.readLine() != null) { }
                p.waitFor();
                handler.post(() -> setStatus("Reboot command sent."));
            } catch (Throwable e) {
                handler.post(() -> {
                    setStatus("Could not run command. Confirm Shizuku is active and permission is granted.");
                    setEnabled(true);
                });
            }
        }).start();
    }

    private void setStatus(String s) {
        status.setText(s);
    }

    private void setEnabled(boolean enabled) {
        cleanButton.setEnabled(enabled);
        cleanButton.setAlpha(enabled ? 1f : 0.55f);
    }

    @Override protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(permissionListener);
        super.onDestroy();
    }
}
